<html>
	<body>
	<?php
		$host='localhost';
		$username='root';
		$password='';
		$dbname = "rayal_restaurant";
		$conn=mysqli_connect($host,$username,$password,$dbname);
		
		// Check connection
		if(!$conn){
			die("ERROR: Could not connect. ". mysqli_connect_error());
		}
		else
		{
			echo "Connected successfully.";
		}

		// if(isset($_POST['save'])){
		// $first_name = $_POST['fname'];
		// $gender = $_POST['gender'];
		// $Email_id = $_POST['mailid'];
		// $phone = $_POST['phone'];
		// $rate=$_POST['rate'];
		

		// $sql = "INSERT INTO contact VALUES ('$first_name','$gender','$Email_id','$phone','$rate');";
			
		// if(mysqli_query($conn, $sql))
		// {
		// 	echo "<h3>data stored in a database successfully.</h3>";
		// 	header("Location: http://localhost/project/contact.html");
		// } 
		// else{
		// 	echo "ERROR: Hush! Sorry $sql. ". mysqli_error($conn);
		// }

		if(isset($_POST['submit']))
		{
			$username = $_POST['username'];  
    		$password = $_POST['password'];  
      
        $sql = "select * from login where USERNAME = '$username' and PASSWORD = '$password'";  
        $result = mysqli_query($conn, $sql);  
        $count = mysqli_num_rows($result);  
          
        if($count == 1){  
			header("Location:http://localhost/project/login_success.html") ;
        }  
        else{  
            header("Location:http://localhost/project/login_failure.html");  
        }  
		
	}
		
		// Close connection
		mysqli_close($conn);
?>
</body>
</html>